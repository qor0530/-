#pragma once
#include <d2d1.h>
class GameObject
{
public:
	ID2D1Bitmap * pBitmap;
};

